export enum ROLE {
  MEMBER = 1,
  ADMIN = 2,
}
