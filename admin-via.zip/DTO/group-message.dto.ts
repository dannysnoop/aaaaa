export class GroupMessageDto {
  groupId = 0;
  take = 0;
  page = 0;
}
